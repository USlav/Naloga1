package si.feri.opj.slavinec.razredi;

public enum OznakaZaboja {
    LOMLJIVO,
    VNETLJIVO,
    BIOLOSKI
}
