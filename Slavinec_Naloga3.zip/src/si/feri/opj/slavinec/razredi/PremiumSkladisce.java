package si.feri.opj.slavinec.razredi;

public class PremiumSkladisce extends Depo {
    private boolean kamera;

    public PremiumSkladisce(String naziv, String lokacija, int stPosiljk, boolean kamera) {
        super(naziv, lokacija, stPosiljk);
        this.kamera = kamera;
    }

    public double vrniCenoSkladiscenja() {
        double osnovnaCena = 0;
        for (int index = 0; index < super.getSeznamPosiljk().length; index++) {
            for (int j = 0; j < super.getSeznamPosiljk()[index].getSeznamArtiklov().length; j++) {
                osnovnaCena += super.getSeznamPosiljk()[index].getSeznamArtiklov()[j].getCena();
            }
        }
        if (kamera) {
            osnovnaCena = osnovnaCena * 2;
        }
        return osnovnaCena;
    }

    @Override
    public String toString() {
        return "PremiumSkladisce{" + super.toString() + ", Kamera: " + kamera + "}";
    }

}
